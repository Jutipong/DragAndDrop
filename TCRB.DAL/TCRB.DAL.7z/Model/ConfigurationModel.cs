﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCRB.DAL.Model
{
    public class ConfigurationModel : EntityModel.Configuration
    {
        public EntityModel.ConfigurationDetail Detail { get; set; }
    }
}
