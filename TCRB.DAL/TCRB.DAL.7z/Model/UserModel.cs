﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCRB.DAL.Model
{
    public class UserModel
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string UserTname { get; set; }
        public string Email { get; set; }
        public string ActiveFlag { get; set; }
        public DateTime? CreateDate { get; set; }
        public string CreateBy { get; set; }
        public DateTime? UpdateDate { get; set; }
        public string UpdateBy { get; set; }
    }
}
