﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCRB.DAL
{
    public interface IDataAccessWrapper
    {
        //IChanelDataAccess ChanelDataAccess { get; }

        void SaveChanges();
        Task SaveChangesAsync();
        int Count<T>(IQueryable<T> query);
    }
}
